# Copy the Chatdb.sql file to your C:\Temp folder

import os
import sqlite3
import datetime

__contact__ = "MSAB.com"
__version__ = "NCCC 2021"
__description__ = "chat db to csv"

file = open(r"C:\Temp\export.csv", "wt")
file.write("MESSAGE,TIMESTAMP,DIRECTION,NAME\n")

buddys = {}

conn = sqlite3.connect(r"C:\Temp\chatdb.sql")
c = conn.cursor()
c.execute("Select [id], [name] from buddyList")

for row in c:
    buddys[row[0]] = row[1]            
c.execute("Select [msg], [stamp], [from], [buddy] from chat")

for row in c:
    msg = row[0]
    stamp = datetime.datetime.utcfromtimestamp(row[1])
    if row[2] == 1:
        direction = "TO"
    else:
        direction = "FROM"
    name = buddys[row[3]]
    print(msg, stamp, direction, name)
    
    file.write("{},{},{},{}\n".format(msg, stamp, direction, name))

file.close()

conn.close()
